document.getElementById('openWebsiteButton').addEventListener('click', paypal );

function paypal() {
    var websiteUrl = 'https://www.paypal.com';
    chrome.tabs.create({ url: websiteUrl });

};